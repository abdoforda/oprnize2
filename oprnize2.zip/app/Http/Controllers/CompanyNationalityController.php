<?php

namespace App\Http\Controllers;

use App\company_nationality;
use Illuminate\Http\Request;

class CompanyNationalityController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\company_nationality  $company_nationality
     * @return \Illuminate\Http\Response
     */
    public function show(company_nationality $company_nationality)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\company_nationality  $company_nationality
     * @return \Illuminate\Http\Response
     */
    public function edit(company_nationality $company_nationality)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\company_nationality  $company_nationality
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, company_nationality $company_nationality)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\company_nationality  $company_nationality
     * @return \Illuminate\Http\Response
     */
    public function destroy(company_nationality $company_nationality)
    {
        //
    }
}
