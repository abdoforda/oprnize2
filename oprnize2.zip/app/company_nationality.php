<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class company_nationality extends Model
{
    //
}
