<?PHP

function lang(){
    return "asdasdasd";
}

function percentage($percentage, $totalWidth){
    return ($percentage / 100) * $totalWidth;
}