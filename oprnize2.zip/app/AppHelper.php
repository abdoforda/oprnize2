<?PHP

namespace App\Helpers;

class AppHelper
{
    public $domain;
}
